function calculateMatrixDiagonalSum(matrix) {
  //your code
}

// Do not remove or change this line, or the tests won't work
export { calculateMatrixDiagonalSum };
