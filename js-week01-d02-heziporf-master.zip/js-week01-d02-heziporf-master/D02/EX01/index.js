function sumNumbersWhileLoop(array) {
  //your code
}

function sumNumbersForLoop(array) {
  //your code
}

// Do not remove or change this line, or the tests won't work
export { sumNumbersWhileLoop, sumNumbersForLoop };
